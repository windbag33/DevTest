﻿using System;
using System.Windows.Forms;
using System.Data;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;


namespace ClientTier
{
    public partial class ClientsNew : Form
    {
        public ClientsNew()
        {
            InitializeComponent();
        }

        //database declarations connections
        ServiceReference1.WebService1SoapClient c = new ServiceReference1.WebService1SoapClient();

        //used for email formatting and validation
        private static Regex email_validation()
        {
            string pattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
                + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
                + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

            return new Regex(pattern, RegexOptions.IgnoreCase);
        }
        static Regex validate_emailaddress = email_validation();


        //button to save data to database
        private void Save_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebService1SoapClient c = new ServiceReference1.WebService1SoapClient();

            ServiceReference1.WebService1SoapClient Client = new ServiceReference1.WebService1SoapClient();
            if (string.IsNullOrEmpty(Email.Text))//if used to check empty text box
            {
                Email.Focus();
                this.Email.Text = "Please enter Email address";
            
            }
            else if (validate_emailaddress.IsMatch(Email.Text) != true)//if used to check if email format is valid
            {
                MessageBox.Show("Please enter the correct Email format", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Email.Focus();
                return;
            }
            else
            {
                c.insertclient(Email.Text, FirstName.Text, Surname.Text, dateTimePicker1.Value.ToString(), Race.Text, Gender.Text, StreetAddress.Text, StreetAddressLine2.Text, City.Text, Province.Text, Convert.ToInt32(ZipCode.Text), Country.Text, WorkAddress.Text, PostalAddress.Text, Convert.ToInt32(CellNumber.Text), Convert.ToInt32(WorkNumber.Text));

                MessageBox.Show("Information Saved");
            }
        }//end save to database 


        //Button Takes user back to Client form 
        private void ClientForm_Click(object sender, EventArgs e)
        {
            this.Hide();
            ClientForm f2 = new ClientForm();
            f2.Show();
        }


        //text box for zipcode requires only numerical values
        private void ZipCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char chr = e.KeyChar;
            if (!Char.IsDigit(chr) && chr != 8)
            {
                e.Handled = true;
                MessageBox.Show("Please enter a numerical value");
            }
        }

        //text box for cell number requires only numerical values
        private void CellNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char chr = e.KeyChar;
            if (!Char.IsDigit(chr) && chr != 8)
            {
                e.Handled = true;
                MessageBox.Show("Please enter a numerical value");
            }
        }

        //text box for Work number requires only numerical values
        private void WorkNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char chr = e.KeyChar;
            if (!Char.IsDigit(chr) && chr != 8)
            {
                e.Handled = true;
                MessageBox.Show("Please enter a numerical value");
            }
        }
    }
    }

