﻿using System;
using System.IO;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ClientTier
{
    public partial class ClientReports : Form
    {
        public ClientReports()
        {
            InitializeComponent();
        }


        //declarations
        ServiceReference1.WebService1SoapClient c = new ServiceReference1.WebService1SoapClient();
        DataTable dt;
        DataSet ds;
        MySqlDataAdapter da;
        MySqlCommand cmd;


        //display data for reports
        private BindingSource ReportsLoad()
        {
            DataTable dt;
            DataSet ds;
            ServiceReference1.WebService1SoapClient c = new ServiceReference1.WebService1SoapClient();

            ServiceReference1.WebService1SoapClient Client = new ServiceReference1.WebService1SoapClient();
            BindingSource bs = new BindingSource();

            ds = Client.client();
            dt = ds.Tables[0];
            bs.DataSource = dt;
            dataGridView1.DataSource = bs;
            MySqlDataAdapter adapter = new MySqlDataAdapter();


            return bs;

        }

        private void ClientReports_Load(object sender, EventArgs e)
        {
            //loads data into the 'clientinformationDataSet.clients' table.
            this.clientsTableAdapter.Fill(this.clientinformationDataSet.clients);

        }

        private void DisplayData_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ReportsLoad();
        }


        //export button exporting data to text file
        private void GenerateCSV_Click(object sender, EventArgs e)
        {
            TextWriter writer = new StreamWriter(@"C:\Users\sjtol\source\repos\ClientInformation.file.txt");
            int rowcount = dataGridView1.Rows.Count;
            for (int i = 0; i < rowcount - 1; i++)
            {
                writer.WriteLine(dataGridView1.Rows[i].Cells[0].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[1].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[2].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[3].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[4].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[5].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[6].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[7].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[8].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[9].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[10].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[11].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[12].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[13].Value.ToString() + ","
                    + dataGridView1.Rows[i].Cells[14].Value.ToString() + ",");
                   
            }
            writer.Close();
            MessageBox.Show("Data Exported");
        }


        //take back to client form
        private void Clientform_Click(object sender, EventArgs e)
        {
            this.Hide();
            ClientForm f2 = new ClientForm();
            f2.Show();
        }

   

    }
}
