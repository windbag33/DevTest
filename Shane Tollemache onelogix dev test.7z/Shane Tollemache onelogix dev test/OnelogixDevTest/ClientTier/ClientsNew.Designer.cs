﻿
namespace ClientTier
{
    partial class ClientsNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Gender = new System.Windows.Forms.ComboBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.Race = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Save = new System.Windows.Forms.Button();
            this.WorkNumber = new System.Windows.Forms.TextBox();
            this.CellNumber = new System.Windows.Forms.TextBox();
            this.PostalAddress = new System.Windows.Forms.TextBox();
            this.WorkAddress = new System.Windows.Forms.TextBox();
            this.Surname = new System.Windows.Forms.TextBox();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.StreetAddresslabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ClientForm = new System.Windows.Forms.Button();
            this.StreetAddressLine2label = new System.Windows.Forms.Label();
            this.StreetAddress = new System.Windows.Forms.TextBox();
            this.StreetAddressLine2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.City = new System.Windows.Forms.TextBox();
            this.ZipCode = new System.Windows.Forms.TextBox();
            this.Province = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Country = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Gender
            // 
            this.Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gender.FormattingEnabled = true;
            this.Gender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.Gender.Location = new System.Drawing.Point(621, 190);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(263, 24);
            this.Gender.TabIndex = 64;
            // 
            // Race
            // 
            this.Race.BackColor = System.Drawing.SystemColors.Window;
            this.Race.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Race.FormattingEnabled = true;
            this.Race.Items.AddRange(new object[] {
            "African",
            "Latino",
            "White",
            "MiddleEastern",
            "Indian"});
            this.Race.Location = new System.Drawing.Point(209, 190);
            this.Race.Name = "Race";
            this.Race.Size = new System.Drawing.Size(260, 24);
            this.Race.TabIndex = 63;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/mm/yyyy";
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(621, 126);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(263, 22);
            this.dateTimePicker1.TabIndex = 62;
            this.dateTimePicker1.Value = new System.DateTime(2021, 2, 27, 0, 0, 0, 0);
            // 
            // Save
            // 
            this.Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Save.Location = new System.Drawing.Point(65, 711);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(168, 44);
            this.Save.TabIndex = 61;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // WorkNumber
            // 
            this.WorkNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WorkNumber.Location = new System.Drawing.Point(621, 570);
            this.WorkNumber.Name = "WorkNumber";
            this.WorkNumber.Size = new System.Drawing.Size(254, 22);
            this.WorkNumber.TabIndex = 58;
            this.WorkNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.WorkNumber_KeyPress);
            // 
            // CellNumber
            // 
            this.CellNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CellNumber.Location = new System.Drawing.Point(209, 570);
            this.CellNumber.Name = "CellNumber";
            this.CellNumber.Size = new System.Drawing.Size(260, 22);
            this.CellNumber.TabIndex = 57;
            this.CellNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CellNumber_KeyPress);
            // 
            // PostalAddress
            // 
            this.PostalAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PostalAddress.Location = new System.Drawing.Point(209, 510);
            this.PostalAddress.Name = "PostalAddress";
            this.PostalAddress.Size = new System.Drawing.Size(666, 22);
            this.PostalAddress.TabIndex = 56;
            // 
            // WorkAddress
            // 
            this.WorkAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WorkAddress.Location = new System.Drawing.Point(209, 453);
            this.WorkAddress.Name = "WorkAddress";
            this.WorkAddress.Size = new System.Drawing.Size(666, 22);
            this.WorkAddress.TabIndex = 55;
            // 
            // Surname
            // 
            this.Surname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Surname.Location = new System.Drawing.Point(209, 128);
            this.Surname.Name = "Surname";
            this.Surname.Size = new System.Drawing.Size(260, 22);
            this.Surname.TabIndex = 53;
            // 
            // FirstName
            // 
            this.FirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstName.Location = new System.Drawing.Point(621, 58);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(263, 22);
            this.FirstName.TabIndex = 52;
            // 
            // Email
            // 
            this.Email.BackColor = System.Drawing.SystemColors.Window;
            this.Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email.Location = new System.Drawing.Point(209, 61);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(263, 22);
            this.Email.TabIndex = 51;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(517, 576);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 16);
            this.label12.TabIndex = 50;
            this.label12.Text = "Work Number";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(65, 576);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 16);
            this.label11.TabIndex = 49;
            this.label11.Text = "Cell Number";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(65, 510);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 16);
            this.label10.TabIndex = 48;
            this.label10.Text = "Postal Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(65, 456);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 16);
            this.label9.TabIndex = 47;
            this.label9.Text = "Work Address";
            // 
            // StreetAddresslabel
            // 
            this.StreetAddresslabel.AutoSize = true;
            this.StreetAddresslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StreetAddresslabel.Location = new System.Drawing.Point(62, 263);
            this.StreetAddresslabel.Name = "StreetAddresslabel";
            this.StreetAddresslabel.Size = new System.Drawing.Size(97, 16);
            this.StreetAddresslabel.TabIndex = 46;
            this.StreetAddresslabel.Text = "Street Address";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(517, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 16);
            this.label7.TabIndex = 45;
            this.label7.Text = "Gender";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(62, 196);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 16);
            this.label6.TabIndex = 44;
            this.label6.Text = "Race";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(517, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 16);
            this.label5.TabIndex = 43;
            this.label5.Text = "Date of Birth";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(65, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 16);
            this.label4.TabIndex = 42;
            this.label4.Text = "Surname";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(517, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 41;
            this.label3.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(65, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 16);
            this.label2.TabIndex = 40;
            this.label2.Text = "Email";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(248, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(353, 24);
            this.label1.TabIndex = 39;
            this.label1.Text = "Please fill out your personal details below";
            // 
            // ClientForm
            // 
            this.ClientForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClientForm.Location = new System.Drawing.Point(707, 705);
            this.ClientForm.Name = "ClientForm";
            this.ClientForm.Size = new System.Drawing.Size(168, 50);
            this.ClientForm.TabIndex = 65;
            this.ClientForm.Text = "Client Form";
            this.ClientForm.UseVisualStyleBackColor = true;
            this.ClientForm.Click += new System.EventHandler(this.ClientForm_Click);
            // 
            // StreetAddressLine2label
            // 
            this.StreetAddressLine2label.AutoSize = true;
            this.StreetAddressLine2label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StreetAddressLine2label.Location = new System.Drawing.Point(62, 307);
            this.StreetAddressLine2label.Name = "StreetAddressLine2label";
            this.StreetAddressLine2label.Size = new System.Drawing.Size(135, 16);
            this.StreetAddressLine2label.TabIndex = 66;
            this.StreetAddressLine2label.Text = "Street Address Line 2";
            // 
            // StreetAddress
            // 
            this.StreetAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StreetAddress.Location = new System.Drawing.Point(209, 257);
            this.StreetAddress.Name = "StreetAddress";
            this.StreetAddress.Size = new System.Drawing.Size(675, 22);
            this.StreetAddress.TabIndex = 67;
            // 
            // StreetAddressLine2
            // 
            this.StreetAddressLine2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StreetAddressLine2.Location = new System.Drawing.Point(209, 304);
            this.StreetAddressLine2.Name = "StreetAddressLine2";
            this.StreetAddressLine2.Size = new System.Drawing.Size(675, 22);
            this.StreetAddressLine2.TabIndex = 68;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(62, 358);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 16);
            this.label8.TabIndex = 69;
            this.label8.Text = "City";
            // 
            // City
            // 
            this.City.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.City.Location = new System.Drawing.Point(209, 355);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(260, 22);
            this.City.TabIndex = 70;
            // 
            // ZipCode
            // 
            this.ZipCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ZipCode.Location = new System.Drawing.Point(209, 405);
            this.ZipCode.Name = "ZipCode";
            this.ZipCode.Size = new System.Drawing.Size(260, 22);
            this.ZipCode.TabIndex = 71;
            this.ZipCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ZipCode_KeyPress);
            // 
            // Province
            // 
            this.Province.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Province.Location = new System.Drawing.Point(621, 361);
            this.Province.Name = "Province";
            this.Province.Size = new System.Drawing.Size(254, 22);
            this.Province.TabIndex = 72;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(517, 361);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 16);
            this.label13.TabIndex = 73;
            this.label13.Text = "Province";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(62, 405);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 16);
            this.label14.TabIndex = 74;
            this.label14.Text = "Zip Code";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(517, 411);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 16);
            this.label15.TabIndex = 75;
            this.label15.Text = "Country";
            // 
            // Country
            // 
            this.Country.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Country.Location = new System.Drawing.Point(621, 407);
            this.Country.Name = "Country";
            this.Country.Size = new System.Drawing.Size(254, 22);
            this.Country.TabIndex = 76;
            // 
            // ClientsNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 1052);
            this.Controls.Add(this.Country);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Province);
            this.Controls.Add(this.ZipCode);
            this.Controls.Add(this.City);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.StreetAddressLine2);
            this.Controls.Add(this.StreetAddress);
            this.Controls.Add(this.StreetAddressLine2label);
            this.Controls.Add(this.ClientForm);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.Race);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.WorkNumber);
            this.Controls.Add(this.CellNumber);
            this.Controls.Add(this.PostalAddress);
            this.Controls.Add(this.WorkAddress);
            this.Controls.Add(this.Surname);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.StreetAddresslabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ClientsNew";
            this.Text = "New Clients";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox Gender;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ComboBox Race;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.TextBox WorkNumber;
        private System.Windows.Forms.TextBox CellNumber;
        private System.Windows.Forms.TextBox PostalAddress;
        private System.Windows.Forms.TextBox WorkAddress;
        private System.Windows.Forms.TextBox Surname;
        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label StreetAddresslabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ClientForm;
        private System.Windows.Forms.Label StreetAddressLine2label;
        private System.Windows.Forms.TextBox StreetAddress;
        private System.Windows.Forms.TextBox StreetAddressLine2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox City;
        private System.Windows.Forms.TextBox ZipCode;
        private System.Windows.Forms.TextBox Province;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox Country;
    }
}