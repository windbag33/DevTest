﻿using System.Data;
using MySql.Data.MySqlClient;


namespace DataTier
{
    //connection to database client information
    public class Dataconnection
    {
        public static MySqlConnection connect = new MySqlConnection("server=localhost; uid=root; pwd=Root; database=clientinformation");
    }
}
