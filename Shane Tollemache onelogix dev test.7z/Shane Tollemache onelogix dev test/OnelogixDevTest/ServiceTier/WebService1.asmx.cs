﻿using System;
using System.Web.Services;
using System.Data;
using DataTier;


namespace ServiceTier
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        // clients used as reference
        Clients clients = new Clients();

        [WebMethod]

        //display clientinformation in report form
        public DataSet client()
        {
            return clients.displayclientinfo();
        }


        //insert client information through new client form also using clients dataset
        [WebMethod]
        public DataSet insertclient(string Email, string FirstName, string Surname, string DateofBirth, string Race, string Gender, string StreetAddress, string StreetAddressLine2, string City, string Province, int Zipcode, string Country, string WorkAddress, string PostalAddress, int CellNumber, int WorkNumber)
        {
            return clients.insertclients(Email, FirstName, Surname, DateofBirth, Race, Gender, StreetAddress, StreetAddressLine2, City, Province, Zipcode, Country, WorkAddress, PostalAddress, CellNumber, WorkNumber);
        }

    }
}
