﻿using System.Data;
using MySql.Data.MySqlClient;

namespace ServiceTier
{
    public class Clients
    {

        //selecting data from clients table for display used in webservice1 and report form
        public DataSet displayclientinfo()
        {
            DataTier.Dataconnection.connect.Close();
            DataTier.Dataconnection.connect.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM clients", DataTier.Dataconnection.connect);

            MySqlDataAdapter da = new MySqlDataAdapter(cmd);

            DataSet ds = new DataSet();

            da.Fill(ds);

            return ds;
        }//end of method connecting to datatier and selecting from clients table in clientinformation database to be used for creating reports


        //insert client information into client table used in webservice1 insert webmethod
        public DataSet insertclients(string Email, string FirstName, string Surname, string DateofBirth, string Race, string Gender, string StreetAddress, string StreetAddressLine2, string City, string Province, int Zipcode, string Country, string WorkAddress, string PostalAddress, int CellNumber, int WorkNumber)
        {
            DataTier.Dataconnection.connect.Close();
            DataTier.Dataconnection.connect.Open();

            MySqlCommand cmd = new MySqlCommand("INSERT INTO clients (Email, FirstName, Surname, DateofBirth, Race, Gender, StreetAddress, StreetAddressLine2, City, Province, Zipcode, Country, WorkAddress, PostalAddress, CellNumber, WorkNumber ) VALUES('" + Email + "','" + FirstName + "','" + Surname + "','" + DateofBirth + "','" + Race + "','" + Gender + "','" + StreetAddress + "','" + StreetAddressLine2 + "','" + City + "','" + Province + "','" + Zipcode + "','" + Country + "','" + WorkAddress + "','" + PostalAddress + "','" + CellNumber + "','" + WorkNumber + "')", DataTier.Dataconnection.connect);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        //end of insert method clients

    }
}
